---
name: revisar-estadisticas
description: Analiza las estadísticas de tus reels o vídeos (capturas o datos) y saca conclusiones concretas para el siguiente. Úsala cuando digas «mira las estadísticas», «cómo va el reel», «qué está fallando» o cuando pegues capturas de Instagram o YouTube Studio.
---

# Revisar estadísticas

## Qué mirar (por orden de importancia)
1. **Retención:** dónde se va la gente. Si cae mucho en los 2 primeros segundos, falla el gancho.
2. **Compartidos y guardados:** si el contenido es útil.
3. **Comentarios:** si genera conversación.
4. **Me gusta:** lo que menos dice.
5. **De dónde viene la gente** (seguidores o no) y su edad, para saber si llegas a quien quieres.

## Entrega
- Una tabla con los datos de cada pieza, copiados tal cual.
- **3 conclusiones** como mucho, cada una con su prueba («la retención cae del 100 % al 50 % en el segundo 2 → el gancho no engancha»).
- **Qué cambiar en el siguiente**, en 2–3 acciones concretas.
- Guarda las conclusiones en un archivo `aprendizajes.md` del proyecto, para no repetir errores.

## Reglas
- Con pocos datos (menos de 300 visualizaciones), dilo: las conclusiones son provisionales.
- No inventes números ni compares con medias que no tengas.

---
name: nombre-de-tu-skill
description: Qué hace en una frase. Úsala cuando digas «…», «…» o «…» (pon aquí las palabras que usas tú al pedirlo: es lo que lee Claude para decidir si la usa).
---

# Nombre de tu skill

## Lo que necesitas antes de empezar
- Qué datos o archivos tiene que tener Claude. Si falta algo, que pregunte solo eso.

## Cómo hacerlo (paso a paso)
1. …
2. …
3. …

## Cómo lo quiero (formato de la entrega)
- Estructura exacta, en el mismo orden siempre.
- Un ejemplo real de cómo debe quedar (pega uno tuyo que te guste).

## Reglas
- Tono: …
- Lo que nunca debe hacer: …

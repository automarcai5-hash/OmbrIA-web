---
name: descripcion-youtube
description: Escribe la descripción de un vídeo de YouTube siempre con la misma estructura (enlace al regalo, resumen, capítulos, sobre mí y hashtags). Úsala cuando digas «hazme la descripción», «pon los capítulos», «los minutos del vídeo» o cuando pases una transcripción o un guion de un vídeo que vas a subir.
---

# Descripción de YouTube

## Lo que necesitas
- La transcripción (mejor con marcas de tiempo) o el guion.
- El enlace del regalo o recurso del vídeo. Si falta, pregunta solo eso.

## Estructura (siempre esta, en este orden)
```
👇 Si eres [quién], estás en [situación] y quieres [resultado], descarga gratis [el regalo]: [enlace con UTM]

[Párrafo 1: qué pasa en el vídeo y qué consigues, con la herramienta por su nombre.]

[Párrafo 2: qué enseñas paso a paso: la prueba, los trucos, lo que falla y las dudas.]

⏱️ CAPÍTULOS
00:00 - [Gancho]
mm:ss - [Bloque]

👋 Sobre mí
[Tu texto de siempre: quién eres y a quién ayudas. Cámbialo aquí una vez.]

#Herramienta #Tema (5–7 hashtags, los más importantes primero)
```

## Capítulos
- El primero siempre `00:00`, al menos 3 y de menor a mayor.
- Si la transcripción no trae tiempos, **no los inventes**: calcula aproximados (150 palabras por minuto) y avisa de que hay que revisarlos.

## Reglas
- Frases cortas, en primera persona y sin superlativos vacíos.
- Corrige los nombres que la transcripción escribe mal («cloud code» → Claude Code).
- Al final, propón el **comentario fijado** (el mismo CTA de la primera línea).

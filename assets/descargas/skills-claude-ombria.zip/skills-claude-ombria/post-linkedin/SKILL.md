---
name: post-linkedin
description: Convierte un vídeo, un reel o una idea en un post de LinkedIn pensado para dueños de empresa (qué ganan, no la herramienta). Úsala cuando digas «hazme el post de LinkedIn», «pásalo a LinkedIn» o cuando pegues la transcripción de un vídeo para reutilizarla.
---

# Post de LinkedIn

## Para quién
Dueños y responsables de empresa. Les importa el **resultado**: horas que se ahorran, errores que se evitan, clientes que no se pierden. La herramienta va en segundo plano.

## Estructura
1. **Primera línea:** el problema o el resultado, en menos de 12 palabras. Es lo único que se ve antes de «ver más».
2. **Contexto (2–3 líneas):** la situación real.
3. **Lo que hice:** 3–5 puntos cortos.
4. **Lo que gana una empresa:** una frase concreta.
5. **Pregunta final** para que comenten.
6. 3 hashtags como mucho.

## Reglas
- Párrafos de 1–2 líneas, con aire entre ellos.
- Sin emojis de adorno (como mucho uno al principio de los puntos).
- El enlace al vídeo no va en el post: va en el **primer comentario** (escríbelo aparte).
- Solo datos reales.

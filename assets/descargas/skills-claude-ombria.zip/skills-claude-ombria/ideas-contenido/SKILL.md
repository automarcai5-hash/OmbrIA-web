---
name: ideas-contenido
description: Propone ideas de vídeos y reels a partir de lo que ya ha funcionado, de novedades de IA con nombre propio y de lo que pregunta tu audiencia. Úsala cuando digas «dame ideas», «qué grabo esta semana», «ideas para reels», «ideas para YouTube» o cuando pegues un perfil o un vídeo de referencia para sacar ideas.
---

# Ideas de contenido

## Antes de proponer
1. Pregunta (solo si no lo sabes): de qué va tu canal, para quién es y qué vídeos te han funcionado mejor.
2. Si te paso vídeos de referencia, quédate con la **idea**, nunca con el guion ni con las frases.

## Cómo pensar cada idea
- **El gancho es la herramienta o la novedad con su nombre** (Claude, Gemini, un repositorio de GitHub que está de moda…). Es lo que hace que alguien se pare.
- Dentro del vídeo, lo útil: qué es, una prueba real, lo que sorprende y lo que falla.
- Si una idea ya funcionó, propón **otra versión** con un ángulo distinto. Repetir lo que funciona no es copiarse.

## Entrega
Una tabla con 5–8 ideas:

| # | Título o gancho (máx. 8 palabras) | De qué va | Por qué puede funcionar | Formato (reel / vídeo largo) |

Debajo, marca con ⭐ las 2 que grabarías primero y explica por qué en una frase.

## Reglas
- Nada de cifras ni datos inventados: si no lo sabes, dilo.
- Frases cortas, sin tecnicismos.

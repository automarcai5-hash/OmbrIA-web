---
name: guion-reel
description: Escribe guiones de reels de 20–40 segundos listos para grabar a cámara, con gancho, texto, moraleja y llamada a la acción. Úsala cuando digas «hazme el guion», «guion para un reel de…», «qué digo en el reel» o cuando pases una idea o una herramienta para convertirla en reel.
---

# Guion de reel

## Estructura (siempre esta)
1. **Gancho (0–3 s):** una frase que se entienda en medio segundo. La herramienta o el resultado por su nombre. Nunca «Hola, soy…».
2. **Por qué importa (3–8 s):** una frase.
3. **Lo que se ve (8–30 s):** la prueba o los pasos, en frases cortas que se puedan decir de un tirón.
4. **Moraleja:** una lección que se pueda aplicar.
5. **CTA:** una sola acción. Por ejemplo: «Comenta PALABRA y te mando la guía» o «Sígueme, que subo mucho de esto».

## Entrega
- **3 ganchos** distintos para elegir.
- El texto para decir a cámara, con una línea en blanco entre frases (así se graba con pausas y se corta mejor).
- **Texto en pantalla** del gancho (máx. 2 líneas cortas).
- **Descripción** del reel (3–4 líneas) y 3–5 hashtags.
- Duración estimada (unas 150 palabras por minuto).

## Reglas
- Tono cercano, como si se lo explicaras a un amigo. Sin tecnicismos ni palabras de vendedor.
- Solo datos reales: si citas un tiempo o una cifra, tiene que salir de una prueba de verdad.
